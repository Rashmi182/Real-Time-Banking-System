package com.Bank.App;

import com.Bank.DAO.CustomerDAO;
import com.Bank.DAO.CustomerDAOImpl;
import com.Bank.DAO.TransactionDAO;
import com.Bank.DAO.TransactionDAOImpl;
import com.Bank.DTO.Customer;
import com.Bank.DTO.Transaction;
import com.Bank.DTO.TransactionID;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class DepositServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to deposit page to allow user to input amount
        RequestDispatcher dispatcher = request.getRequestDispatcher("deposit.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String message = null;

        try {
            // Get the account number and amount from the request
            long accountNumber = Long.parseLong(request.getParameter("accountNumber"));
            double amount = Double.parseDouble(request.getParameter("amount"));

            // Create DAO objects for Customer and Transaction
            CustomerDAO cdao = new CustomerDAOImpl();
            TransactionDAO tdao = new TransactionDAOImpl();

            // Retrieve the customer from the account number
            Customer c = cdao.getCustomer(accountNumber);

            // Check if the entered amount is valid and deposit
            if (c != null && amount > 0) {
                c.setBalance(c.getBalance() + amount);

                boolean updateRes = cdao.updateCustomer(c);
                if (updateRes) {
                    // Record the transaction
                    Transaction t = new Transaction();
                    t.setTransactionId(TransactionID.generateTransactionId());
                    t.setUser(c.getAccno());
                    t.setRec_acc(c.getAccno());
                    t.setTransaction("CREDITED");
                    t.setAmount(amount);
                    t.setBalance(c.getBalance());

                    boolean transactionRes = tdao.insertTransaction(t);
                    if (transactionRes) {
                        // Success message
                        message = "Amount of Rs. " + amount + " has been added successfully! Your updated balance is Rs. " + c.getBalance();
                    } else {
                        message = "Failed to deposit! Try again later.";
                    }
                } else {
                    message = "Failed to deposit! Try again later.";
                }
            } else {
                message = "Invalid amount entered.";
            }

        } catch (NumberFormatException e) {
            message = "Invalid input. Please enter valid account number and amount.";
        }

        // Set the message as an attribute to display in the JSP
        request.setAttribute("message", message);

        // Forward to the result page (for displaying messages)
        RequestDispatcher dispatcher = request.getRequestDispatcher("depositResult.jsp");
        dispatcher.forward(request, response);
    }
}
