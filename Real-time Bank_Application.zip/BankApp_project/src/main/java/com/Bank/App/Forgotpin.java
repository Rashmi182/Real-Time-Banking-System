package com.Bank.App;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.Bank.DAO.CustomerDAO;
import com.Bank.DAO.CustomerDAOImpl;
import com.Bank.DTO.Customer;

@WebServlet("/forgotpin")
public class Forgotpin extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String accountNumberStr = req.getParameter("number");
        String phoneStr = req.getParameter("tel");
        String email = req.getParameter("mail");
        String pinStr = req.getParameter("pin");
        String confirmPinStr = req.getParameter("Confirmpin");

        String message = validateInputs(accountNumberStr, phoneStr, email, pinStr, confirmPinStr);
        if (message != null) {
            forwardWithMessage(req, resp, "failure", message);
            return;
        }

        try {
            long accountNumber = Long.parseLong(accountNumberStr);
            long phone = Long.parseLong(phoneStr);
            int pin = Integer.parseInt(pinStr);

            CustomerDAO cdao = new CustomerDAOImpl();
            Customer c = cdao.getCustomer(phone, email);

            if (c == null) {
                forwardWithMessage(req, resp, "failure", "No user found with the provided details.");
                return;
            }

            c.setPin(pin);
            boolean isUpdated = cdao.updateCustomer(c);
            String resultMessage = isUpdated ? "Password updated successfully." : "Failed to update password. Please try again later.";
            forwardWithMessage(req, resp, isUpdated ? "success" : "failure", resultMessage);
        } catch (NumberFormatException e) {
            forwardWithMessage(req, resp, "failure", "Invalid number format. Please check your input.");
        } catch (Exception e) {
            forwardWithMessage(req, resp, "failure", "An unexpected error occurred: " + e.getMessage());
        }
    }

    private String validateInputs(String accountNumber, String phone, String email, String pin, String confirmPin) {
        if (accountNumber == null || accountNumber.isEmpty() ||
            phone == null || phone.isEmpty() ||
            email == null || email.isEmpty() ||
            pin == null || pin.isEmpty() ||
            confirmPin == null || confirmPin.isEmpty()) {
            return "All fields are required!";
        }
        if (!pin.equals(confirmPin)) {
            return "Passwords do not match!";
        }
        return null;
    }

    private void forwardWithMessage(HttpServletRequest req, HttpServletResponse resp, String type, String message) throws ServletException, IOException {
        req.setAttribute(type, message);
        RequestDispatcher dispatcher = req.getRequestDispatcher("forgotpin.jsp");
        dispatcher.forward(req, resp);
    }
}


