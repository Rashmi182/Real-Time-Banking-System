package com.Bank.App; 

//	RESETPIN CLASS
import java.util.Scanner; 
import com.Bank.DAO.CustomerDAO; 
import com.Bank.DAO.CustomerDAOImpl; 
import com.Bank.DTO.Customer; 

public class ResetPin {
	public static void resetPin(Customer c) {
		Scanner sc=new Scanner(System.in);
		CustomerDAO cdao=new CustomerDAOImpl();
		
		System.out.println("Enter the Account Number");
		long accno=sc.nextLong();
		
		
		System.out.println("Enter the Phone Number");
		long phone=sc.nextLong();
		
		if(accno==c.getAccno() && phone==c.getPhone()) {
			System.out.println("Enter the new PIN to reset");
			int pin=sc.nextInt();
			System.out.println("Confirm pin");
			int comfirm=sc.nextInt();
			
			if(pin==comfirm) {
				c.setPin(pin);
				boolean res=cdao.updateCustomer(c);
				
				if(res) {
					System.out.println("PIN reset successfully");
					
				}
				else {
					System.out.println("Failed to reset");
				}
			}
			else {
				System.out.println("Pin mismatch or incorrect pin");
			}
		}
		else {
			System.out.println("Incorrect Account number or phone number");
		}
		
	}

}

