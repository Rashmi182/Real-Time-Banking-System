package com.Bank.App;

import java.io.IOException;

import com.Bank.DAO.CustomerDAO;
import com.Bank.DAO.CustomerDAOImpl;
import com.Bank.DTO.Customer;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/signup")
public class signup extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Collecting the data from the user
        String name = req.getParameter("name");
        String phoneStr = req.getParameter("phone");
        String mail = req.getParameter("mail");
        String pinStr = req.getParameter("pin");
        String confirmPinStr = req.getParameter("confirmPin");

        // Converting phone and pin to proper data types
        long phone = Long.parseLong(phoneStr);
        int pin = Integer.parseInt(pinStr);
        int confirmPin = Integer.parseInt(confirmPinStr);

        // DAO and DTO objects
        Customer c = new Customer();
        CustomerDAO cdao = new CustomerDAOImpl();

        // Logic for sign-up
        if (pin == confirmPin) {
            c.setName(name);
            c.setPhone(phone);
            c.setMail(mail);
            c.setPin(pin);

            boolean result = cdao.insertCustomer(c);

            if (result) {
//                c = cdao.getCustomer(phone, mail);
//                req.setAttribute("successMessage", "Signup successful! Your account number is: " + c.getAccno());
                
            	req.setAttribute("success","Account created successful");
 			   	RequestDispatcher rd=req.getRequestDispatcher("signup.jsp");
 			   	rd.forward(req, resp);
            } else {
                // If the insertion fails
                req.setAttribute("failure", "Already have an account for these credentials. Please try again.");
                RequestDispatcher rd = req.getRequestDispatcher("signup.jsp");
                rd.forward(req, resp);
            }
        }
            else {
            	req.setAttribute("failure","PIN and Confirm PIN do not match. Please try again.");
 			    RequestDispatcher rd=req.getRequestDispatcher("signup.jsp");
 			    rd.forward(req, resp);
            }
        
    }
}
